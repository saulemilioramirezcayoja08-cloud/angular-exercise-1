import { Component } from '@angular/core';

@Component({
  selector: 'app-top-left',
  standalone: false,
  templateUrl: './top-left.html',
  styleUrl: './top-left.css'
})
export class TopLeft {

}
