export interface ProductSearchParams {
  sku?: string;
  name?: string;
}
